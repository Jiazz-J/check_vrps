package com.virtusa.vrps;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Encoder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String password = "91234";
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        System.out.println(passwordEncoder.encode(password));

	}

}
