package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Work;

public interface WorkRepo extends JpaRepository<Work, Integer>{

	@Query("SELECT wk FROM Work wk WHERE wk.employee.employeeId = :employeeid")
	Work getUserWorkByID(@Param("employeeid") int employeeid);
	
	@Query("SELECT DISTINCT wk FROM Work wk inner join Application ap on wk.employee.employeeId = ap.employee.employeeId  WHERE ap.adminStatus = :code and wk.job.jobId=:jobId")
	List<Work> customeWorkListAdmin(@Param("code") int code,@Param("jobId") int jobId);
	
	@Query("SELECT wk FROM Work wk inner join Application ap on wk.employee.employeeId = ap.employee.employeeId  WHERE ap.trStatus = :code and wk.job.jobId=:jobId")
	List<Work> customeWorkListTr(@Param("code") int code,@Param("jobId") int jobId);
	
	@Query("SELECT wk FROM Work wk inner join Application ap on wk.employee.employeeId = ap.employee.employeeId  WHERE ap.hrStatus = :code and wk.job.jobId=:jobId")
	List<Work> customeWorkListHr(@Param("code") int code,@Param("jobId") int jobId);
	
	@Query("SELECT wk FROM Work wk inner join Application ap on wk.employee.employeeId = ap.employee.employeeId  WHERE ap.adminStatus = :code and ap.trStatus = :code2 and wk.job.jobId=:jobId")
	List<Work> customeWorkListViewAdmin(@Param("code") int code,@Param("code2") int code2,@Param("jobId") int jobId);
	
	@Query("SELECT wk FROM Work wk inner join Application ap on wk.employee.employeeId = ap.employee.employeeId  WHERE ap.trStatus = :code and ap.hrStatus = :code2 and wk.job.jobId=:jobId")
	List<Work> customeWorkListViewTr(@Param("code") int code,@Param("code2") int code2,@Param("jobId") int jobId);
	
	
	
}
