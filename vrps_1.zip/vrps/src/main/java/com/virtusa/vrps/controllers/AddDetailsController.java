package com.virtusa.vrps.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.virtusa.vrps.VrpsApplication;
import com.virtusa.vrps.models.Admin;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.PersonRole;
import com.virtusa.vrps.services.AdminService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonRoleService;
import com.virtusa.vrps.services.PersonalService;

@Controller
@RequestMapping("admin/addDetails")
public class AddDetailsController {
	
	private static final Logger logger=Logger.getLogger(AddDetailsController.class);
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private PersonRoleService personRoleService;
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/addTrHr")
	public String addUser() {
		return "addTrHr";
	}

	@PostMapping("/addUserTrHr")
	public String addTrHr(@ModelAttribute("admin") Admin admin, @ModelAttribute PersonRole personRole, Model model) {

		
		logger.info("Adding TR or HR");
		admin.setPassword(new BCryptPasswordEncoder().encode(admin.getPassword()));
		try {
		adminService.saveAdmin(admin);
		personRole.setPerson(admin);

		personRoleService.savePersonRole(personRole);
		}
		catch (Exception e) {
			logger.error(e);
		}

		model.addAttribute("success", true);

		return "addTrHr";

	}

	@GetMapping("/addEmployee")
	public String addUserEmp() {
		
		
		return "addEmployee";
	}

	@PostMapping("/addUserEmployee")
	public String addEmployee(@ModelAttribute Employee employee, @ModelAttribute PersonRole personRole, Model model) {
		employee.setPassword(new BCryptPasswordEncoder().encode(employee.getPassword()));

		logger.info("Adding Employee");
		employeeService.savEmployee(employee);
		personRole.setPerson(employee);

		personRoleService.savePersonRole(personRole);

		model.addAttribute("success", true);

		return "addEmployee";
	}
	
	@GetMapping("/addJob")
	public String addJob(@ModelAttribute Job job,Model model) {
		try {
		model.addAttribute("jobs",jobService.selectJobs());
		}
		catch (Exception e) {
			logger.error(e);
		}
		return "addJob";
	}
	
	
	@PostMapping("/addJobDetails")
	public String addJobDetails(@ModelAttribute Job job,Model model) {
		
		try {
		jobService.saveJob(job);
		logger.info("Saving job");
		model.addAttribute("success", true);
		}
		catch (Exception e) {
			// TODO: handle exceptio
			logger.error(e);
		}
		return "addJob";
		
		
		
	}


}
