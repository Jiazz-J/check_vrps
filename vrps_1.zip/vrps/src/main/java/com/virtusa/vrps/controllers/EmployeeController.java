package com.virtusa.vrps.controllers;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.trace.http.HttpTrace.Principal;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.JobService;

@Controller
@RequestMapping("/user")
public class EmployeeController {
    
	private static final Logger logger=Logger.getLogger(EmployeeController.class);
	
	@Autowired
	private ApplicationService applicationService;
	
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	private JobService jobService;
	
	@GetMapping("/employeeHome")
	public String employeeHome() {
	
		try {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		int employeeId=Integer.parseInt(authentication.getName());
		httpSession.setAttribute("userId", employeeId);
		httpSession.setAttribute("role", authentication.getAuthorities());
		
		
		logger.info(Integer.parseInt(httpSession.getAttribute("userId").toString())+"  name  "+authentication.getAuthorities() );
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		
		return "employeeHome";
	}

	
}
