package com.virtusa.vrps.controllers;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ErrorController {

	private static final Logger logger=Logger.getLogger(ErrorController.class);
 

    @ExceptionHandler(Throwable.class)
    @ResponseStatus (HttpStatus.INTERNAL_SERVER_ERROR)
    public String exception(final Throwable throwable, final Model model) {
        
    	try {
        String errorMessage = (throwable != null ? throwable.getMessage() : "Unknown error");
        model.addAttribute("errorMessage", errorMessage);
    	}
    	catch (Exception e) {
			// TODO: handle exception
    		logger.error(e);
		}
        return "error";
    }
   
   

}