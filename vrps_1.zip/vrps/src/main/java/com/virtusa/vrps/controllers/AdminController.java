package com.virtusa.vrps.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.vrps.VrpsApplication;
import com.virtusa.vrps.models.Admin;
import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.Person;
import com.virtusa.vrps.models.PersonRole;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.RatingAndComments;
import com.virtusa.vrps.repositories.ApplicationRepo;
import com.virtusa.vrps.services.AdminService;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonRoleService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.RatingAndCommentsService;
import com.virtusa.vrps.services.WorkService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	private static final Logger logger=Logger.getLogger(AdminController.class);
	

	@Autowired
	HttpSession httpSession;

	@Autowired
	private PersonalService personalService;

	@Autowired
	private EducationService educationService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private WorkService workService;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private AdminService adminService;
	@Autowired
	private PersonRoleService personRoleService;
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private RatingAndCommentsService ratingAndCommentsService;

	@ModelAttribute("personalDetails")
	public List<Personal> getAllPersonalDetails() {
		return personalService.getAllPersonal();
	}

	@PostMapping("/employeeStatus")
	public String selected(@RequestParam("employeeId") int employeeId,@RequestParam("result") String result,RatingAndComments rAC) {
		int statusCode=0;
		
		logger.info("employee status");
		logger.info(result);
		logger.error("no error in AdminController");
		try {
		if(httpSession.getAttribute("userId")==null)
		    	return "login";
		//employeeId = Integer.parseInt(employeeId));
		 
		 int adminId=Integer.parseInt(httpSession.getAttribute("userId").toString());
		 Admin admin = adminService.getAdminById(adminId);
		 Employee employee = employeeService.getEmployee(employeeId);
		 Job job=jobService.getJob(Integer.parseInt(httpSession.getAttribute("jobId").toString()));
		 rAC.setAdmin(admin);
		 rAC.setEmployee(employee);
		 rAC.setJob(job);
		 ratingAndCommentsService.saveRatingAndComment(rAC);
		 System.out.print(employeeId);
	     String role=httpSession.getAttribute("role").toString();
		 applicationService.updateStatus(employeeId, role, result,job.getJobId());
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		 return "redirect:jobsSelected";
	}
	

	@GetMapping("/viewcandidate")
	public String employeeList(Model model,@Param("jobId") int jobId) {
		try {
		if (httpSession.getAttribute("userId") == null)
			return "login";
		String Role = httpSession.getAttribute("role").toString();
		System.out.println("jobid"+jobId);
		httpSession.setAttribute("jobId", jobId);
		
		logger.info("view candidates");
		logger.error("no error in AdminController");
		
		model.addAttribute("workDetails", workService.customeFindAllWorkDetails(Role,jobId));
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		
		return "viewcandidate";
	}

	@GetMapping("/viewselectedcandidate")
	public String selectedemployeeList(Model model,@Param("jobId") int jobId) {
		
		try {
		if (httpSession.getAttribute("userId") == null)
			return "login";
		
		logger.info("selected candidates");
		logger.error("no error in AdminController");
		String Role = httpSession.getAttribute("role").toString();
		httpSession.setAttribute("jobId", jobId);
		model.addAttribute("workDetails", workService.customeFindSelectedWorkDetails(Role,jobId));
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		return "viewcandidate";
	}

	@GetMapping( "/viewemployeedetail")
	public String abcd(@RequestParam("id") String id,Model model) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		logger.info("id:"+id);
		
		logger.info("view employee details");
		logger.error("no error in AdminController");
		try {
		int employeeId = Integer.parseInt(id);
		int jobId=Integer.parseInt(httpSession.getAttribute("jobId").toString());
		String Role=httpSession.getAttribute("role").toString();
		Application application=applicationService.getApplicationDetailsByEmployeeId(employeeId,jobId);
		if(Role.contains("ADMIN") && application.getAdminStatus()==0) {
			model.addAttribute("pageType", true);
			
		}
		else if(Role.contains("HR") && application.getHrStatus()==0) {
			model.addAttribute("pageType", true);
			
		}
		else if(Role.contains("TR") && application.getTrStatus()==0) {
			model.addAttribute("pageType", true);
	
		}
		else {
			model.addAttribute("pageType", false);
		}
		model.addAttribute("personal", personalService.getPersonalById(employeeId));
		model.addAttribute("educations", educationService.getEducationById(employeeId));
		//model.addAttribute("work", workService.getWorkById(employeeId));
		model.addAttribute("companies", companyService.getCompanyByEmployeeId(employeeId));
		model.addAttribute("feedback", ratingAndCommentsService.getRatingsAndComments(employeeId,jobId));
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		return "candidateProfile";
	}
	

	@GetMapping("/adminHome")
	public String adminHome() {

		try {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		int employeeId = Integer.parseInt(authentication.getName());
		httpSession.setAttribute("userId", employeeId);
		httpSession.setAttribute("role", authentication.getAuthorities());

		logger.info("Admin Home");
		logger.error("no error in AdminController");
		logger.info(Integer.parseInt(httpSession.getAttribute("userId").toString()) + "  name  "
				+ authentication.getAuthorities());
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		
		return "adminHome";
	}

	@GetMapping("/candidateProfile")
	public String candidateProfile() {
		
		logger.info("candidates profile");
		logger.error("no error in AdminController");
		if (httpSession.getAttribute("userId") == null)
		{
			logger.error("aceess denied");
			return "login";
		}
		return "candidateProfile";
	}

		@GetMapping("/jobsSelected")
	public String getSelectedJobs(Model model)
	{
		logger.info("selected jobs");
		logger.error("no error in AdminController");
		try {
		model.addAttribute("jobs",jobService.selectJobs());
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		return "jobsSelected";
	}
	@GetMapping("/jobs")
	public String getJobs(Model model)
	{
		
		logger.info("jobs");
		logger.error("no error in AdminController");
		try {
		model.addAttribute("jobs",jobService.selectJobs());
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error(e);
		}
		return "jobs";
	}
	
	
}
