package com.virtusa.vrps.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.virtusa.vrps.models.Admin;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.PersonRole;
import com.virtusa.vrps.repositories.EmployeeRepo;
import com.virtusa.vrps.repositories.PersonRoleRepo;
import com.virtusa.vrps.services.AdminService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonRoleService;

@Controller
public class HomeController {
	
	private static final Logger logger=Logger.getLogger(HomeController.class);
	 
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private PersonRoleService personRoleService;
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	HttpSession httpSession;
	
   @GetMapping("/")
   public String login()
   {
	   return "login";
   }
   
   @GetMapping("/user/logout")
   public String logout()
   {
	   try {
	   httpSession.removeAttribute("userId");
	   httpSession.removeAttribute("role");
	
	   httpSession.invalidate();
	   }
	   catch (Exception e) {
		// TODO: handle exception
		   logger.error(e);
	}
	   return "redirect:/";
	  
   }
   @GetMapping("/admin/logout")
   public String adminLogout()
   {
	   try {
	   httpSession.removeAttribute("userId");
	   httpSession.removeAttribute("role");
	
	   httpSession.invalidate();
	   }
	   catch (Exception e) {
		// TODO: handle exception
		   logger.error(e);
	}
	   return "redirect:/";
	  
   }
   
   
}