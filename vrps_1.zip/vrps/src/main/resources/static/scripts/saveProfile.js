var groupeducation = [];
var groupcompany = [];
$(document).ready(function() {

	$("#regForm").submit(function(event) {

		
		event.preventDefault();

		

		fire_ajax_submit();

		window.location.href = "/user/applied";

	});

	$("#addeducation").click(function(event) {

		var course = $("#course").val();
		var branch = $("#branch").val();
		var institutionName = $("#institutionName").val();
		var percentage = $("#percentage").val();
		var passYear = $("#passYear").val();

		$('#educlose').trigger('click');
		var education = {
			"course" : course,
			"branch" : branch,
			"institutionName" : institutionName,
			"percentage" : percentage,
			"passYear" : passYear
		}
		eduprint(education);
		groupeducation.push(education);

	});

	$("#addCompanydetails").click(function(event) {
		var companyName = $("#companyName").val();
		var designation = $("#designation").val();
		var startDate = $("#startDate").val();
		var endDate = $("#endDate").val();
		var previousPackage = $("#previousPackage").val();
		var technologiesWorked = $("#technologiesWorked").val();

		$('#companyclose').trigger('click');

		var company = {
			"companyName" : companyName,
			"designation" : designation,
			"startDate" : startDate,
			"endDate" : endDate,
			"previousPackage" : previousPackage,
			"technologiesWorked" : technologiesWorked,
		}

		comprint(company)
		groupcompany.push(company);
	});
});

function comprint(company) {

	
	var $tr = $('<tr>');

	$.each(company, function(i, item) {

		$tr.append($('<td>').text(item)); 

	});

	$('#companydd').append($tr);

	$("#nextBtn").prop("disabled", false);

}

function eduprint(education) {

	
	var $tr = $('<tr>');
	$.each(education, function(i, item) {

		$tr.append($('<td>').text(item)); 

	});

	$('#educationdd').append($tr)

	$("#nextBtn").prop("disabled", false);

}


function fire_ajax_submit() {

	
	var fullName = $("#name").val();
	var dob = $("#dob").val();
	var gender = $("input[name='gender']:checked").val();
	var mobile = $("#mobile").val();
	var email = $("#email").val();
	var address = $("#address").val();

	console.log(fullName + "name");
	console.log(gender + "gender");
	console.log(mobile + "mobile");
	console.log(email + "em;ai");
	// work
	var experience = $("#experience").val();
	var location = $("#location").val();
	var projectStatus = $("#projectStatus").val();
	var skills = $("#skills").val();

	var ref=Math.floor(10*10+Math.random()*90000000);
	

		var personal = {

		"address" : address,

		"dob" : dob,

		"email" : email,
		"gender" : gender,
		"mobile" : mobile,

		"name" : fullName,
		

	}

	var work = {
		"experience" : experience,
		"location" : location,
		"projectStatus" : projectStatus,
		"skills" : skills,
		
	}
	
	var application ={
			"referenceId"	:ref,
				
		}

	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/user/savePersonal",
		data : JSON.stringify(personal),
		cache : false,
		timeout : 600000,
		success : function(data) {

		

			
		},
		error : function(e) {

			var json = "<h4>Ajax Response</h4><pre>" + e.responseText
					+ "</pre>";
			$('#feedback').html(json);

			console.log("ERROR : ", e);
			

		}

	});

	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/saveWork",
		data : JSON.stringify(work),
		dataType : 'json',
		cache : false,
		timeout : 600000,
		success : function(data) {

			

			
		},
		error : function(e) {

			var json = "<h4>Ajax Response</h4><pre>" + e.responseText
					+ "</pre>";
			$('#feedback').html(json);

			console.log("ERROR : ", e);
			
		}

	});

	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/saveEducation",
		data : JSON.stringify(groupeducation),
		dataType : 'json',
		cache : false,
		timeout : 600000,
		success : function(data) {

			

		
		},
		error : function(e) {

			var json = "<h4>Ajax Response</h4><pre>" + e.responseText
					+ "</pre>";
			$('#company').html(json);

			console.log("ERROR : ", e);
			

		}

	});

	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/saveCompany",
		data : JSON.stringify(groupcompany),
		dataType : 'json',
		cache : false,
		timeout : 600000,
	
	});
	
	
	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/saveApplication",
		data : JSON.stringify(application),
		dataType : 'json',
		cache : false,
		timeout : 600000,
	
	});

}
