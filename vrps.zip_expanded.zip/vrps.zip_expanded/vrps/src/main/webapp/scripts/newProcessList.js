/**
 * 
 */
window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}




	document.querySelector("form").addEventListener("submit",function(){

		ajaxObject.open("post","../NewProcessList",true);
		var processName=document.querySelector("#processName").value;
		var processCode=document.querySelector("#processCode").value;
		var description=document.querySelector("#description").value;
		ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
		ajaxObject.send("processName="+processName+"&description="+description+"&processCode="+processCode);
		
		var formRef=document.querySelector("form");
		
		ajaxObject.onreadystatechange=function()
		{
			if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
				console.log(ajaxObject.responseText);
				element=document.createElement("p");
				textNode=document.createTextNode(ajaxObject.responseText);
				element.appendChild(textNode);
				formRef.appendChild(element);
			}
			
		}
		



	});
		});
