package com.virtusa.vrps.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.virtusa.vrps.dao.implementations.UsersImp;
import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.models.WorkDetails;

/**
 * Servlet implementation class ViewEmployeeList
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ViewEmployeeList" })
public class ViewEmployeeList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		String type = request.getParameter("type");
		System.out.println(type + " in the type of type");

		int Type_code = 0;
		if (type.equalsIgnoreCase("SC")) {
			Type_code = 1;
		}
		HttpSession session = request.getSession();
		// String employeeId = (String) session.getAttribute("employeeId");
		String designation = (String) session.getAttribute("Designation");
		UsersDao userDao = new UsersImp();
		try {
			List<WorkDetails> employeeList = userDao.getWorkDetails(designation, Type_code);
			for (WorkDetails workDetails : employeeList) {
				System.out.println(workDetails.getEmpID());
				System.out.println(workDetails.getDesignation());
				System.out.println(workDetails.getExperience());
			}

			response.getWriter().write(new Gson().toJson(employeeList));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
