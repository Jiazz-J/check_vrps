package com.virtusa.vrps.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import com.virtusa.vrps.dao.interfaces.ProcessList;
import com.virtusa.vrps.helpers.OracleHelper;
import com.virtusa.vrps.models.JobProcessList;

public class JobProcessListImp implements ProcessList {

	private Connection conn;
	private CallableStatement callable;
	private int status = 0;
	private static ResourceBundle rb;
	private Statement statement;
	private ResultSet resultSet;

	{
		rb = ResourceBundle.getBundle("com/virtusa/vrps/resources/db");
	}

	@Override
	public boolean addProcess(JobProcessList jobProcessList) {
		System.out.println("in the process list");
		conn = OracleHelper.getConnection();
		try {
			statement = conn.createStatement();

			String getUsersQuery = rb.getString("getAdminProcessCount");
			resultSet = statement.executeQuery(getUsersQuery + jobProcessList.getCreatorName() + "'");
			if (resultSet.next()) {
				jobProcessList.setId("pro0" + resultSet.getString(1) + jobProcessList.getCreatorName().substring(0, 3));
				System.out.println(resultSet.getString(1));
			} else {
				System.out.println("nothing");
				jobProcessList.setId("pro00" + jobProcessList.getCreatorName().substring(0, 3));
			}
			callable = conn.prepareCall("insert into processlist values(?,?,?,?,?,?)");
			callable.setString(1, jobProcessList.getId());
			callable.setString(2, jobProcessList.getProcessName());
			callable.setString(3, jobProcessList.getCreatorName());
			callable.setString(4, jobProcessList.getProcessCode());
			callable.setString(5, jobProcessList.getDescrption());
			callable.setDate(6, Date.valueOf(jobProcessList.getCreatedDate()));

			status = callable.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("error:" + e.toString());
			e.printStackTrace();
		}
		System.out.println("sql status : " + status);
		return false;
	}

	@Override
	public boolean deleteProcess(String processName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(JobProcessList jobProcessList) {
		// TODO Auto-generated method stub

		return false;
	}

}
