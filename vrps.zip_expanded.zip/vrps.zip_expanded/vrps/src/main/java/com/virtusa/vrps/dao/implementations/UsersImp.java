package com.virtusa.vrps.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.helpers.OracleHelper;
import com.virtusa.vrps.models.EducationDetails;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.InsertComment;
import com.virtusa.vrps.models.PersonalDetails;
import com.virtusa.vrps.models.Projects;
import com.virtusa.vrps.models.Users;
import com.virtusa.vrps.models.WorkDetails;

public class UsersImp implements UsersDao {

	private ResourceBundle rb;
	private Connection conn;
	private Statement statement;
	private ResultSet resultSet;
	private Users users;

	@Override
	public List<Users> getAllUsers() throws SQLException {
		// TODO Auto-generated method stub

		List<Users> userList = new ArrayList<Users>();
		rb = ResourceBundle.getBundle("com/virtusa/vrps/resources/db");
		String getUsersQuery = rb.getString("getUsersQuery");

		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		resultSet = statement.executeQuery(getUsersQuery);
		// users = new Users();
		while (resultSet.next()) {
			users = new Users();
			users.setUserId(resultSet.getString(1));
			users.setUserPassword(resultSet.getString(2));
			users.setDesignation(resultSet.getString(3));

			userList.add(users);

		}
		conn.close();

		return userList;
	}

	@Override
	public boolean setCreateProfile(Employee employee) throws SQLException {
		// TODO Auto-generated method stub

		conn = OracleHelper.getConnection();

		boolean status = false;

		conn.setAutoCommit(false);
		CallableStatement callableStatement = conn.prepareCall("{call personaldetails_proc(?,?,?,?,?,?,?)}");
		callableStatement.setString(1, employee.getEmployeeId());
		callableStatement.setString(2, employee.getPersonalDetails().getFullName());
		callableStatement.setDate(3, new java.sql.Date(employee.getPersonalDetails().getDob().getTime()));
		callableStatement.setString(4, employee.getPersonalDetails().getGender());
		callableStatement.setLong(5, employee.getPersonalDetails().getMobile());
		callableStatement.setString(6, employee.getPersonalDetails().getEmail());
		callableStatement.setString(7, employee.getPersonalDetails().getAddress());
		int result1 = callableStatement.executeUpdate();

		CallableStatement callableStatement2 = conn.prepareCall("{call workdetails_proc(?,?,?,?,?,?,?,?)}");
		callableStatement2.setString(1, employee.getEmployeeId());
		callableStatement2.setString(2, employee.getWorkDetails().getDesignation());
		callableStatement2.setInt(3, employee.getWorkDetails().getCtc());
		callableStatement2.setString(4, employee.getWorkDetails().getCurrentLocation());
		callableStatement2.setString(5, employee.getWorkDetails().getRequiredLocation());
		callableStatement2.setInt(6, employee.getWorkDetails().getExperience());
		callableStatement2.setString(7, employee.getWorkDetails().getAppliedjob());
		callableStatement2.setString(8, employee.getWorkDetails().getSkills());
		int result2 = callableStatement2.executeUpdate();

		CallableStatement callableStatement3 = conn.prepareCall("{ call projects_proc(?,?,?,?,?) }");
		callableStatement3.setString(1, employee.getEmployeeId());
		callableStatement3.setString(2, employee.getProjects().getTitle());
		callableStatement3.setDate(3, new java.sql.Date(employee.getProjects().getStartdate().getTime()));
		callableStatement3.setDate(4, new java.sql.Date(employee.getProjects().getEnddate().getTime()));
		callableStatement3.setString(5, employee.getProjects().getDescription());
		int result3 = callableStatement3.executeUpdate();

		CallableStatement callableStatement4 = conn
				.prepareCall("{ call educationdetails_proc(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
		callableStatement4.setString(1, employee.getEmployeeId());
		callableStatement4.setString(2, employee.getEducationDetails().getSchoolName());
		callableStatement4.setInt(3, employee.getEducationDetails().getSchoolPercent());
		callableStatement4.setInt(4, employee.getEducationDetails().getSchoolPassYear());
		callableStatement4.setString(5, employee.getEducationDetails().getCollegeName());
		callableStatement4.setInt(6, employee.getEducationDetails().getCollegePercent());
		callableStatement4.setInt(7, employee.getEducationDetails().getCollegePassYear());
		callableStatement4.setString(8, employee.getEducationDetails().getEngCourseType());
		callableStatement4.setString(9, employee.getEducationDetails().getEngCollegeName());
		callableStatement4.setInt(10, employee.getEducationDetails().getEngPercent());
		callableStatement4.setInt(11, employee.getEducationDetails().getEngPassYear());
		// callableStatement4.setString(,
		// employee.getEducationDetails().getSchoolName());
		callableStatement4.setString(12, employee.getEducationDetails().getpGCourseType());
		callableStatement4.setString(13, employee.getEducationDetails().getpGCollegeName());
		callableStatement4.setInt(14, employee.getEducationDetails().getpGPercent());
		callableStatement4.setInt(15, employee.getEducationDetails().getpGPassYear());
		int result4 = callableStatement4.executeUpdate();

		CallableStatement callableStatement5 = conn.prepareCall("{call applicationstatus_proc(?,?)}");
		callableStatement5.setString(1, employee.getEmployeeId());
		callableStatement5.setString(2, employee.getReferenceId());
		int result5 = callableStatement5.executeUpdate();

		if (result1 + result2 + result3 + result4 + result5 == 5)
			status = true;
		System.out.println(result1 + " in the userminp");

		conn.commit();

		return status;
	}

	@Override
	public List<WorkDetails> getWorkDetails(String Designation, int typeCode) throws SQLException {
		List<WorkDetails> workDetailList = new ArrayList<WorkDetails>();
		rb = ResourceBundle.getBundle("com.virtusa.vrps.resources.db");
		WorkDetails workDetail;
		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		String Query = null;
		if (Designation.equalsIgnoreCase("ADMIN")) {
			Query = "select * from workDetails inner join applicationstatus on workDetails.EMPID = applicationstatus.EMPID where ADMIN='"
					+ typeCode + "'";

			System.out.println("enter into  problem" + Designation + "  " + typeCode);

		} else if (Designation.equalsIgnoreCase("TR")) {
			if (typeCode == 0) {
				Query = "select * from workDetails inner join applicationstatus on workDetails.EMPID = applicationstatus.EMPID where ADMIN=1";

				System.out.println("enter into " + Designation + "  " + typeCode);

			} else {
				Query = "select * from workDetails inner join applicationstatus on workDetails.EMPID = applicationstatus.EMPID where TR="
						+ typeCode;

				System.out.println("enter into " + Designation + "  " + typeCode);
			}
		} else {
			if (typeCode == 0) {
				Query = "select * from workDetails inner join applicationstatus on workDetails.EMPID = applicationstatus.EMPID where TR=1";

				System.out.println("enter into " + Designation + "  " + typeCode);

			} else {

				Query = "select * from workDetails inner join applicationstatus on workDetails.EMPID = applicationstatus.EMPID where HR="
						+ typeCode;

				System.out.println("enter into " + Designation + "  " + typeCode);
			}

		}
		resultSet = statement.executeQuery(Query);
		// users = new Users();
		while (resultSet.next()) {
			try {
				workDetail = new WorkDetails(resultSet.getString(2), resultSet.getInt(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getInt(6), resultSet.getString(7), resultSet.getString(8));
				workDetail.setEmpID(resultSet.getString(1));

				workDetailList.add(workDetail);
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		}
		conn.close();

		return workDetailList;
	}

	@Override
	public Employee getEmployeeDetails(String employeeID) throws SQLException {

		PersonalDetails personalDetails = null;
		EducationDetails educatonDetails = null;
		Projects projects = null;
		WorkDetails workDetails = null;
		String refID = null;
		rb = ResourceBundle.getBundle("com.virtusa.vrps.resources.db");
		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		resultSet = statement.executeQuery(
				"select * from PERSONALDETAILS inner join EDUCATIONDETAILS on PERSONALDETAILS.EMPID = EDUCATIONDETAILS.EMPID inner join PROJECTS on PROJECTS.EMPID = PERSONALDETAILS.EMPID inner join WORKDETAILS on WORKDETAILS.EMPID = PERSONALDETAILS.EMPID inner join APPLICATIONSTATUS on APPLICATIONSTATUS.EMPID = PERSONALDETAILS.EMPID where PERSONALDETAILS.EMPID='"
						+ employeeID + "'");
		while (resultSet.next()) {
			personalDetails = new PersonalDetails(resultSet.getString(2), resultSet.getDate(3), resultSet.getString(4),
					resultSet.getLong(5), resultSet.getString(6), resultSet.getString(7));
			educatonDetails = new EducationDetails(resultSet.getString(9), resultSet.getInt(10), resultSet.getInt(11),
					resultSet.getString(12), resultSet.getInt(13), resultSet.getInt(14), resultSet.getString(15),
					resultSet.getString(16), resultSet.getInt(17), resultSet.getInt(18), resultSet.getString(19),
					resultSet.getString(20), resultSet.getInt(21), resultSet.getInt(22));
			projects = new Projects(resultSet.getString(24), resultSet.getDate(25), resultSet.getDate(26),
					resultSet.getString(27));
			workDetails = new WorkDetails(resultSet.getString(29), resultSet.getInt(30), resultSet.getString(31),
					resultSet.getString(32), resultSet.getInt(33), resultSet.getString(34), resultSet.getString(35));
			refID = resultSet.getString(37);
		}
		Employee employee = new Employee(employeeID, educatonDetails, personalDetails, workDetails, projects, refID);
		return employee;
	}

	@Override
	public boolean insertComment(InsertComment insertComment) throws SQLException {
		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		ResultSet resultset = null;
		boolean status = false;
		System.out.println(insertComment.getEmpId() + " " + insertComment.getAdminId());
		try {
			resultset = statement.executeQuery("select * from commentAndRating where EMPID='" + insertComment.getEmpId()
					+ "' and ADMINID='" + insertComment.getAdminId() + "'");
		} catch (Exception e) {
			System.out.println("error " + e.toString());
		}

		if (resultset != null && resultset.next()) {
			resultset = statement.executeQuery("delete from commentAndRating where EMPID='" + insertComment.getEmpId()
					+ "' and ADMINID='" + insertComment.getAdminId() + "'");
		}
		CallableStatement callableStatement = conn.prepareCall("insert into commentAndRating values(?,?,?,?)");
		callableStatement.setString(1, insertComment.getEmpId());
		callableStatement.setString(2, insertComment.getAdminId());
		callableStatement.setString(3, insertComment.getComment());
		callableStatement.setInt(4, insertComment.getRating());
		int result = callableStatement.executeUpdate();
		if (result == 1) {
			status = true;
		}

		return status;
	}

	@Override
	public boolean selectOrReject(String Designation, String EmpID, String result) throws SQLException {
		conn = OracleHelper.getConnection();
		statement = conn.createStatement();
		ResultSet resultset = null;
		boolean status = false;

		CallableStatement callableStatement = conn
				.prepareCall("update applicationstatus set ADMIN=?,TR=?,HR=? where EMPID='" + EmpID + "'");
		// callableStatement.setString(4, EmpID);
		if (result.equalsIgnoreCase("selected")) {
			switch (Designation) {

			case "Admin":
				callableStatement.setInt(1, 1);

				callableStatement.setInt(2, 0);
				callableStatement.setInt(3, 0);

				break;
			case "TR":
				callableStatement.setInt(1, 1);
				callableStatement.setInt(2, 1);
				callableStatement.setInt(3, 0);
				break;
			case "HR":

				callableStatement.setInt(1, 1);
				callableStatement.setInt(2, 1);

				callableStatement.setInt(3, 1);
				break;

			}
		} else {

			callableStatement.setInt(1, 2);
			callableStatement.setInt(2, 2);
			callableStatement.setInt(3, 2);
		}
		int resultStatus = callableStatement.executeUpdate();
		if (resultStatus == 1) {
			status = true;
		}
		return status;
	}

}
