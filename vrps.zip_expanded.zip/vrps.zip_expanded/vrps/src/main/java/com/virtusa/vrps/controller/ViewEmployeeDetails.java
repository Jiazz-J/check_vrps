package com.virtusa.vrps.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.virtusa.vrps.dao.implementations.UsersImp;
import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.models.Employee;

/**
 * Servlet implementation class ViewEmployeeDetails
 */
@WebServlet("/ViewEmployeeDetails")
public class ViewEmployeeDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewEmployeeDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		String employeeId = (String) session.getAttribute("employeeId");
		String designation = (String) session.getAttribute("Designation");
		System.out.println(employeeId+" "+designation);
		
		String empID=request.getParameter("empID");
		System.out.println(empID);
		UsersDao userDao=new UsersImp();
		Employee employee=null;
		try {
			employee=userDao.getEmployeeDetails(empID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(new Gson().toJson(employee));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
