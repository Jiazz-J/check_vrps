package com.virtusa.vrps.models;

public class EducationDetails {
	private String schoolName;
	private int schoolPercent;
	private int schoolPassYear;

	private String collegeName;
	private int collegePercent;
	private int collegePassYear;

	private String engCourseType;
	private String engCollegeName;

	public EducationDetails(String schoolName, int schoolPercent, int schoolPassYear, String collegeName,
			int collegePercent, int collegePassYear, String engCourseType, String engCollegeName, int engPercent,
			int engPassYear, String pGCourseType, String pGCollegeName, int pGPercent, int pGPassYear) {
		super();
		this.schoolName = schoolName;
		this.schoolPercent = schoolPercent;
		this.schoolPassYear = schoolPassYear;
		this.collegeName = collegeName;
		this.collegePercent = collegePercent;
		this.collegePassYear = collegePassYear;
		this.engCourseType = engCourseType;
		this.engCollegeName = engCollegeName;
		this.engPercent = engPercent;
		this.engPassYear = engPassYear;
		this.pGCourseType = pGCourseType;
		this.pGCollegeName = pGCollegeName;
		this.pGPercent = pGPercent;
		this.pGPassYear = pGPassYear;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public int getSchoolPercent() {
		return schoolPercent;
	}

	public void setSchoolPercent(int schoolPercent) {
		this.schoolPercent = schoolPercent;
	}

	public int getSchoolPassYear() {
		return schoolPassYear;
	}

	public void setSchoolPassYear(int schoolPassYear) {
		this.schoolPassYear = schoolPassYear;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getCollegePercent() {
		return collegePercent;
	}

	public void setCollegePercent(int collegePercent) {
		this.collegePercent = collegePercent;
	}

	public int getCollegePassYear() {
		return collegePassYear;
	}

	public void setCollegePassYear(int collegePassYear) {
		this.collegePassYear = collegePassYear;
	}

	public String getEngCourseType() {
		return engCourseType;
	}

	public void setEngCourseType(String engCourseType) {
		this.engCourseType = engCourseType;
	}

	public String getEngCollegeName() {
		return engCollegeName;
	}

	public void setEngCollegeName(String engCollegeName) {
		this.engCollegeName = engCollegeName;
	}

	public int getEngPercent() {
		return engPercent;
	}

	public void setEngPercent(int engPercent) {
		this.engPercent = engPercent;
	}

	public int getEngPassYear() {
		return engPassYear;
	}

	public void setEngPassYear(int engPassYear) {
		this.engPassYear = engPassYear;
	}

	public String getpGCourseType() {
		return pGCourseType;
	}

	public void setpGCourseType(String pGCourseType) {
		this.pGCourseType = pGCourseType;
	}

	public String getpGCollegeName() {
		return pGCollegeName;
	}

	public void setpGCollegeName(String pGCollegeName) {
		this.pGCollegeName = pGCollegeName;
	}

	public int getpGPercent() {
		return pGPercent;
	}

	public void setpGPercent(int pGPercent) {
		this.pGPercent = pGPercent;
	}

	public int getpGPassYear() {
		return pGPassYear;
	}

	public void setpGPassYear(int pGPassYear) {
		this.pGPassYear = pGPassYear;
	}

	private int engPercent;
	private int engPassYear;

	private String pGCourseType;

	private String pGCollegeName;
	private int pGPercent;
	private int pGPassYear;

}
