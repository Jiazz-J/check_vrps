var groupeducation = [];
var groupcompany = [];
$(document).ready(function() {
	$("#education").click(function(event) {

		event.preventDefault();
		education_submit();
		window.location.href = "/company";
	});
	$("#company").click(function(event) {
		
		event.preventDefault();
		company_submit();
		window.location.href = "/jobList";
	});
	
	
	$("#addeducation").click(function(event) {

		var course = $("#course").val();
		var branch = $("#branch").val();
		var institutionName = $("#institutionName").val();
		var percentage = $("#percentage").val();
		var passYear = $("#passYear").val();

		$('#educlose').trigger('click');
		var education = {
			"course" : course,
			"branch" : branch,
			"institutionName" : institutionName,
			"percentage" : percentage,
			"passYear" : passYear
		}
		eduprint(education);
		groupeducation.push(education);

	});
	

	$("#addCompanydetails").click(function(event) {
		var companyName = $("#companyName").val();
		var designation = $("#designation").val();
		var startDate = $("#startDate").val();
		var endDate = $("#endDate").val();
		var previousPackage = $("#previousPackage").val();
		var technologiesWorked = $("#technologiesWorked").val();

		$('#companyclose').trigger('click');

		var company = {
			"companyName" : companyName,
			"designation" : designation,
			"startDate" : startDate,
			"endDate" : endDate,
			"previousPackage" : previousPackage,
			"technologiesWorked" : technologiesWorked,
		}

		comprint(company)
		groupcompany.push(company);
	});
});

function comprint(company) {

	
	var $tr = $('<tr>');

	$.each(company, function(i, item) {

		$tr.append($('<td>').text(item)); 

	});

	$('#companydd').append($tr);

	//$("#nextBtn").prop("disabled", false);

}

function eduprint(education) {

	
	var $tr = $('<tr>');
	$.each(education, function(i, item) {

		$tr.append($('<td>').text(item)); 
       
	});
   
	$('#educationdd').append($tr)

	//$("#nextBtn").prop("disabled", false);

}


	
function education_submit()
{
	
$.ajax({
	type : "POST",
	contentType : "application/json",
	url : "/saveeducation",
	data : JSON.stringify(groupeducation),
	dataType : 'json',
	cache : false,
	timeout : 600000,
	success : function(data) {

		

	
	},
	error : function(e) {

		var json = "<h4>Ajax Response</h4><pre>" + e.responseText
				+ "</pre>";
		$('#company').html(json);

		console.log("ERROR : ", e);
		

	}

});
}
function company_submit() {
	
	$.ajax({

		type : "POST",
		contentType : "application/json",
		url : "/savecompany",
		data : JSON.stringify(groupcompany),
		dataType : 'json',
		cache : false,
		timeout : 600000,
	
	});
	
}
