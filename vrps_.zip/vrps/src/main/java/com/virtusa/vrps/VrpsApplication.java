package com.virtusa.vrps;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VrpsApplication {

	
	private static final Logger logger=Logger.getLogger(VrpsApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(VrpsApplication.class, args);
		
		logger.debug(args);
		logger.info("vrps application");
		logger.error("no error upto here");
		
		
		
		
	}

}


