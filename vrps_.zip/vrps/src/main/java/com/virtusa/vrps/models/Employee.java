package com.virtusa.vrps.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
@PrimaryKeyJoinColumn(name = "EmployeeId")
public class Employee extends Person {

	}
