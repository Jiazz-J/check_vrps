package com.virtusa.vrps.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.repositories.ApplicationRepo;

@Service
public class ApplicationService {

	@Autowired
	private ApplicationRepo applicationRepo;
	
	public Application saveApplication(Application application) {
		return applicationRepo.save(application);

	}

	public List<Application> getAllApplications() {
		return applicationRepo.findAll();

	}

	public Application getApplicationById(int applicationId) {
		return applicationRepo.findById(applicationId).orElse(null);
	}
	
	public Application updateStatus(int employeeId,String Role,String result,int JobId) {
		int code=0;
		if(result.equals("rejected"))
			code=2;
		 else
			 code=1;		
		Application application=applicationRepo.getApplicationByEmployeeAndJobId(employeeId,JobId);
		if(Role.contains("ADMIN")) {
			application.setAdminStatus(code);
		}
		else if(Role.contains("TR")) {
			application.setTrStatus(code);
		}
		else if(Role.contains("HR")) {
			application.setHrStatus(code);
		}
		applicationRepo.deleteById(application.getApplicationId());
		return applicationRepo.save(application);
	}

	
	public Application getApplicationByRefId(long referenceId)
	{
		Application application=applicationRepo.getStatusByRefId(referenceId);
		System.out.println("adminid="+application.getAdminStatus());
		System.out.print(application);
		return application;
	}

	public long getApplicationByEmployeeAndJobId(int employeeId,int jobId)
	{
		long referenceId=0;
		Application application =	applicationRepo.getApplicationByEmployeeAndJobId(employeeId,jobId);
		if(application!=null)
			referenceId =application.getReferenceId();
		return referenceId;
	}
	public Application getApplicationDetailsByEmployeeId(int employeeId,int jobId)
	{
		long referenceId=0;
		Application application =	applicationRepo.getApplicationByEmployeeAndJobId(employeeId,jobId);
		return application;
	}
	public Application getApplicationByEmployeeId(int employeeId)
	{
		long referenceId=0;
		Application application =	applicationRepo.getApplicationByEmployeeId(employeeId);
		return application;
	}
	
	
}
