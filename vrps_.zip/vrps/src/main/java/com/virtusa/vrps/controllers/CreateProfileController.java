package com.virtusa.vrps.controllers;

import java.lang.ProcessBuilder.Redirect;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.JobService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class CreateProfileController {

	@Autowired
	private PersonalService personalService;

	@Autowired
	private WorkService workService;

	@Autowired
	EmployeeService employeeService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EducationService educationService;
	@Autowired
	private ApplicationService applicationService;
    @Autowired
    private JobService jobService;
	
	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    @Autowired
	HttpSession httpSession;

	/*@RequestMapping(value = "/savePersonal", method = RequestMethod.POST)
	public @ResponseBody String savePersonal(@RequestBody Personal personal, Employee employee, Model model) {
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());

		employee = employeeService.getEmployee(employeeId);
		personal.setEmployee(employee);
		model.addAttribute("personal", personalService.savePersonal(personal));

		String userId = authentication.getName();
		String role = authentication.getAuthorities().toString();

		System.out.println("this is from " + userId + "  " + role);

		return "";

	}

	@RequestMapping(value = "/saveWork", method = RequestMethod.POST)
	public @ResponseBody void saveWork(@RequestBody Work work, Employee employee, Model model) { //
		
		 //model.addAttribute("work", workService.saveWork(work)); employee = //
		// employeeService.getEmployee(1234); work.setEmployee(employee);
		 // workService.saveWork(work);
		 
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		employee = employeeService.getEmployee(employeeId);
		work.setEmployee(employee);
		model.addAttribute("personal", workService.saveWork(work));

	}

	@RequestMapping(value = "/saveCompany", method = RequestMethod.POST)

	public @ResponseBody void saveCompany(@RequestBody Company[] groupcompany, Employee employee, Model model) {

		// model.addAttribute("company", companyService.saveCompany(company));
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		Work work=workService.getWorkById(employeeId);
		for (int i = 0; i < groupcompany.length; i++) {
			groupcompany[i].setWork(work);
			companyService.saveCompany(groupcompany[i]);
		}
	}

	@RequestMapping(value = "/saveEducation", method = RequestMethod.POST)

	public @ResponseBody void saveEducation(@RequestBody Education[] groupeducation, Employee employee, Model model) {
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		employee = employeeService.getEmployee(employeeId);
		
		for (int i = 0; i < groupeducation.length; i++) {
			groupeducation[i].setEmployee(employee);
			
			educationService.saveEducation(groupeducation[i]);
		}

	}

	
	
	  @RequestMapping(value = "/saveApplication", method = RequestMethod.POST)
	  public @ResponseBody void saveApplication(@RequestBody Application
	  application, Employee employee, Model model) { //
	  
	  //model.addAttribute("work", workService.saveWork(work)); employee = // //
	  //employeeService.getEmployee(1234);
	  
	  
	  int
	  employeeId=Integer.parseInt(httpSession.getAttribute("userId").toString());
	  employee = employeeService.getEmployee(employeeId);
	  int jobid =Integer.parseInt(httpSession.getAttribute("jobId").toString());
	  Job job=jobService.getJob(jobid);
	  application.setJob(job);
	  application.setEmployee(employee);
	  model.addAttribute("application",applicationService.saveApplication(
	  application));
	  
	  
	  
	  
	  }*/
    @GetMapping("/apply")
    public String apply()
    {
    	return "redirect:personal";
    }
	@GetMapping("/personal")
	public String personal()
	{
		String employeeId=httpSession.getAttribute("userId").toString();
		if(employeeId==null)
			return "login";
		Personal personal=personalService.getPersonalById(Integer.parseInt(employeeId));
		if(personal!=null)
		{
			return "redirect:education";
		}
		//int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		return "personal";
	}
	@PostMapping("/savepersonal")
	public String savePersonal(Model model,Personal personal,Employee employee)
	{
		String employeeId=httpSession.getAttribute("userId").toString();
		if(employeeId==null)
			return "login";
		System.out.println(personal.getEmail());
		employee = employeeService.getEmployee(Integer.parseInt(employeeId));
	    personal.setEmployee(employee);
	    personalService.savePersonal(personal);
		return "redirect:education";
	}
	
	@GetMapping("/education")
	public String education()
	{
		String employeeId=httpSession.getAttribute("userId").toString();
		if(employeeId==null)
			return "login";
		if(educationService.getEducationById(Integer.parseInt(employeeId)).size()!=0)
		{
			return "redirect:company";
		}
		//int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
	   
		//model.addAttribute("personal", personalService.savePersonal(personal));

		return "education";
	}
	@PostMapping("/saveeducation")
	public String saveEducation(@RequestBody Education[] educations, Employee employee, Model model)
	{
		  String employeeId=httpSession.getAttribute("userId").toString();
		   if(employeeId==null)
			return "login";
		    employee = employeeService.getEmployee(Integer.parseInt(employeeId));
		    
				for(int i=0;i<educations.length;i++)
				{
				educations[i].setEmployee(employee);	
				educationService.saveEducation(educations[i]);
			}
		    return "redirect:/company";
	}
	@GetMapping("/company")
	public String company()
	{
		String employeeId=httpSession.getAttribute("userId").toString();
		if(employeeId==null)
			return "login";
		if(companyService.getCompanyByEmployeeId(Integer.parseInt(employeeId)).size()!=0)
		{
			return "redirect:jobList";
		}
		//int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
	   
		//model.addAttribute("personal", personalService.savePersonal(personal));

		return "company";
	}
	@PostMapping("/savecompany")
	public String saveCompany(@RequestBody Company[] company, Employee employee, Model model)
	{
		  String employeeId=httpSession.getAttribute("userId").toString();
		   if(employeeId==null)
			return "login";
		    employee = employeeService.getEmployee(Integer.parseInt(employeeId));
		    
				for(int i=0;i<company.length;i++)
				{
				 company[i].setEmployee(employee);	
				 companyService.saveCompany(company[i]);
			    }
		    return "redirect:/jobList";
	}
	
	@GetMapping("/jobList")
	   public String joblist(Model model) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		/*
		 * long referenceId=
		 * applicationService.getApplicationByEmployeeId(Integer.parseInt(httpSession.
		 * getAttribute("userId").toString()));
		 * System.out.print("referenceId"+referenceId); if(referenceId !=0) {
		 * model.addAttribute("referenceId", referenceId); return "applied"; }
		 */
		   else
		   {
		   model.addAttribute("jobs",jobService.selectJobs());
		   return "jobList";
		   }
	   }
		
	    @GetMapping("/work")
		public String createProfile( @Param("jobId") int jobId)
		{
		    System.out.print(httpSession.getAttribute("userId"));
		    if(httpSession.getAttribute("userId")==null)
		    	 return "login";
		    
		    long referenceId=applicationService.getApplicationByEmployeeAndJobId(Integer.parseInt(httpSession.getAttribute("userId").toString()),jobId);
		    httpSession.setAttribute("jobId", jobId);
		    if(referenceId==0)
		    {
					return "work";

		    }
		    else 
		    {
		    	 return "redirect:applied";
			}
		   
		   
			
			
		}
	    @PostMapping("/saveapplication")
	    public  String saveWorkAndApplication( Work work, Employee employee,Job job,Application application)
	    {
	    	
			// TODO Auto-generated method stub
	    	String employeeId=httpSession.getAttribute("userId").toString();
	    	 if(httpSession.getAttribute("userId")==null)
			    	return "login";
	    	 
	    	 System.out.println("in work ");
	    	 employee = employeeService.getEmployee(Integer.parseInt(employeeId));
	    	
	    	 work.setEmployee(employee);
	    	 job=jobService.getJob(Integer.parseInt(httpSession.getAttribute("jobId").toString()));
	    	 work.setJob(job);
	         System.out.println(application.getReferenceId());
	 	      work.setEmployee(employee);
	 	      job=jobService.getJob(Integer.parseInt(httpSession.getAttribute("jobId").toString()));
	 	     work.setJob(job);
	 	     workService.saveWork(work);
	 	     long refereneceId=(long)(Math.floor(1000*1000+Math.random()*90000000));
	 	     System.out.println(refereneceId);
	 	     System.out.println("work saved");
	 	     application.setReferenceId(refereneceId);
	 	     
	 	    application.setEmployee(employee);
	 	    application.setJob(job);
	 	    applicationService.saveApplication(application);
	 	    return "redirect:applied";
	 	    }
	 		
	 		
	  
	    
	  
	    
	 
	 @GetMapping("/applied")
		public String applied(Model model)
		{
		 if(httpSession.getAttribute("userId")==null)
			    	return "login";
		
		  long referenceId= applicationService.getApplicationByEmployeeAndJobId(Integer.parseInt(httpSession.getAttribute("userId").toString()),Integer.parseInt(httpSession.getAttribute("jobId").toString()));
		  System.out.print("referenceId"+referenceId); 
		  if(referenceId !=0) 
		  {
		  model.addAttribute("referenceId", referenceId);
		  return "applied"; 
		  }
		 
			return "applied";
			
		}
	    

	 

}
