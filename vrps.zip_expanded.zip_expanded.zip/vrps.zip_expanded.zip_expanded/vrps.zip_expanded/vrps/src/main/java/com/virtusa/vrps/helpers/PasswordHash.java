package com.virtusa.vrps.helpers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class PasswordHash {

	public String getHash(String password) {

		MessageDigest md;
		byte[] enc_pass = null;
		String hashedString = null;
		try {
			md = MessageDigest.getInstance("MD5");
			byte[] pass_b = password.getBytes(StandardCharsets.UTF_8);
			enc_pass = (md.digest(pass_b));
			hashedString = new String(enc_pass);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return hashedString;

		/*
		 * BigInteger number = new BigInteger(1,enc_pass);
		 * 
		 * StringBuilder hexString = new StringBuilder(number.toString(16));
		 * 
		 * while (hexString.length() < 32) { hexString.insert(0, '0'); }
		 * 
		 * return hexString.toString();
		 */
	}

}
