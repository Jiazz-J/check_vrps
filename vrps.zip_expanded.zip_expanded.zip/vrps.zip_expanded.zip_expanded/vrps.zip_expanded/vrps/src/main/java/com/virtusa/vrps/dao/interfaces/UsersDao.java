package com.virtusa.vrps.dao.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.InsertComment;
import com.virtusa.vrps.models.Users;
import com.virtusa.vrps.models.WorkDetails;

public interface UsersDao {
	List<Users> getAllUsers() throws SQLException;

	boolean setCreateProfile(Employee employee) throws SQLException;

	Employee getEmployeeDetails(String employeeID) throws SQLException;

	List<WorkDetails> getWorkDetails(String designation, int typeCode) throws SQLException;

	boolean insertComment(InsertComment insertComment) throws SQLException;

	boolean selectOrReject(String Designation, String EmpID, String result) throws SQLException;

	ResultSet getViewStatus(String referenceId) throws SQLException;

}
