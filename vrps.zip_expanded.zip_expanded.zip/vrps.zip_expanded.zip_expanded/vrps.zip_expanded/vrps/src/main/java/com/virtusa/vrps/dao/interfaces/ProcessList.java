package com.virtusa.vrps.dao.interfaces;

import com.virtusa.vrps.models.JobProcessList;

public interface ProcessList {
	
	boolean addProcess(JobProcessList jobProcessList) ;
	boolean deleteProcess(String processName);
	boolean update(JobProcessList jobProcessList);

}
