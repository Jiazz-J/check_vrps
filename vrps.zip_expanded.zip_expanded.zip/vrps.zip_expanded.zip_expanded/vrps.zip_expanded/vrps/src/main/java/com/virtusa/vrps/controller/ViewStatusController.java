package com.virtusa.vrps.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.virtusa.vrps.dao.implementations.UsersImp;
import com.virtusa.vrps.dao.interfaces.UsersDao;

/**
 * Servlet implementation class ViewStatusController
 */
@WebServlet("/ViewStatusController")
public class ViewStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String status = "You are at ";
		String message = null;
		System.out.println(request.getParameter("referenceId"));
		ResultSet resultSet = null;
		UsersDao usersDao = new UsersImp();
		try {
			resultSet = usersDao.getViewStatus(request.getParameter("referenceId"));

			if (!resultSet.next()) {
				message = "enter valid referenceId";

			} else {

				// System.out.print(resultSet.next());
				int admin = resultSet.getInt(3);
				int tr = resultSet.getInt(4);
				int hr = resultSet.getInt(5);
				System.out.print(admin + " " + tr + " " + hr);
				if (admin == 2 || tr == 2 || hr == 2) {

					message = "sorry, hope we meet soon";

				} else if (admin == 1) {
					message = "you passed admin test /n";
					if (tr == 1) {
						message += "you passed TR test /n";

						if (hr == 1) {
							message += "you got selected/n";
						}
					}

				} else {
					message = "you are at admin level";
				}

			}
			System.out.println(message);

			response.getWriter().write(new Gson().toJson(message));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
