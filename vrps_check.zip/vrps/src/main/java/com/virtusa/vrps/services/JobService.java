package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Job;
import com.virtusa.vrps.repositories.JobRepo;

@Service
public class JobService {

	@Autowired
	private JobRepo jobRepo;
	
	
	public Job	saveJob(Job job) {
		return jobRepo.save(job);
		
	}
	
	public List<Job> selectJobs() {
		return jobRepo.findAll();
		
	}
	public Job getJob(int jobId)
	{
		return jobRepo.findById(jobId).orElse(null);
	}
	
}
