package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.Personal;


public interface PersonalRepo  extends JpaRepository<Personal, Integer> {
	@Query("SELECT pr FROM Personal pr WHERE pr.Employee.employeeId = :employeeid")
	Personal getUserPersonalByID(@Param("employeeid") int employeeid);
	
	/*
	 * @Query("SELECT pd FROM Personal pd inner join Application ap on pd.employee.employeeId = ap.employee.employeeId  WHERE ap.adminStatus = :code"
	 * ) List<Personal> customePersonalListAdmin(@Param("code") int code);
	 * 
	 * @Query("SELECT pd FROM Personal pd inner join Application ap on pd.employee.employeeId = ap.employee.employeeId  WHERE ap.trStatus = :code"
	 * ) List<Personal> customePersonalListTr(@Param("code") int code);
	 * 
	 * @Query("SELECT pd FROM Personal pd inner join Application ap on pd.employee.employeeId = ap.employee.employeeId  WHERE ap.hrStatus = :code"
	 * ) List<Personal> customePersonalListHr(@Param("code") int code);
	 */
	
}
	

	

