
showTab(0); 





function showTab(n) {
    // This function will display the specified tab of the form...
	 x = document.getElementsByClassName("tab");
    x[n].style.display = "block";
    x[1].style.display = "block";
    x[2].style.display = "block";
    x[3].style.display = "block";
    
    
}


/*
function addEducation()
{
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByTagName("input");
    var course = y["course"].value;
    var branch = y["branch"].value;
    var institutionName = y["institutionName"].value;
    var passYear = y["passYear"].value;
    var percentage = y["percentage"].value;
    if(stringLengthAndEmpty(course))
    {
        y["course"].className += "invalid";
        valid=false;
    }
    else
    {
        y["course"].className += "valid";
    }
    if(stringLengthAndEmpty(institutionName))
    {
        y["institutionName"].className += "invalid";
        valid=false;
    }
    else
    {
        y["institutionName"].className += "valid";
    }
    if(numberLength(percentage) )
    {
        y["percentage"].className += "invalid";
        valid=false;
    }
    else
    {
        y["percentage"].className += "valid";
    }
    if(isYear(passYear))
    {
        y["passYear"].className += "invalid";
        valid=false;
    }
    else
    {
        y["passYear"].className += "valid";
    }


}
function addCompany()
{
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByTagName("input");
    var companyName = y["companyName"].value;
    var designation =y["designation"].value;
    var startDate = y["startDate"].value;
    var endDate =y["endDate"].value;
    var package = y["previousPackage"].value;
    var technologies = y["technologiesWorked"].value;
    if(stringLengthAndEmpty(companyName))
    {
        y["companyName"].className += "invalid";
        valid=false;
    }
    else
    {
        y["companyName"].className += "valid";
    }
    if(stringLengthAndEmpty(designation))
    {
        y["designation"].className += "invalid";
        valid=false;
    }
    else
    {
        y["designation"].className += "valid";
    }
    if(stringLengthAndEmpty(technologies))
    {
        y["technologiesWorked"].className += "invalid";
        valid=false;
    }
    else
    {
        y["technologiesWorked"].className += "valid";
    }
    if(isFutureDate(startDate) || startDate.length==0)
    {
        y["startDate"].className += "invalid";
        valid=false;
    }
    else
    {
        y["startDate"].className += "valid";
    }
    if(isEdLtSd(startDate,endDate) || endDate=="")
    {
        y["endDate"].className += "invalid";
        valid=false;
    }
    else
    {
        y["endDate"].className += "valid";
    }
  
}






function isFutureDate(date)
{
    var date=new Date(date)

    var currentDate = new Date();

    if(date > currentDate)
        return true;

    return false;
}
function isYear(year)
{
    if(year.length==4 || isNaN(year) || year=="")
        return true;

    return false
}
function numberLength(number)
{
    if(number.length>2 || isNaN(number) || number=="")
        return true;

    return false;
}
function stringLengthAndEmpty(string)
{
    if(string.length>=50 || string=="")
        return true;

    return false;

}
function isEdLtSd(startdate,enddate)
{

    if(startdate > enddate)
        return true;
    return false;
}

*/